"""
The three answering strategies brief section 5 asks to compare (weak-logit-
bias, the 4th condition, deprioritized for this pilot -- noted honestly in
outputs/akew_answering_results.md rather than silently skipped):

  no_context:           the untouched base model, no evidence at all.
                        This is the REJECT path's actual behavior.
  hard_playback:        return the stored fact directly, no generation, no
                        reasoning. Structured mode: the target_new the editor
                        was legitimately given at install time (not a gold
                        leak -- that IS the edit spec in structured mode).
                        Unstructured/extracted: the raw evidence text
                        verbatim, since there is no discrete "answer" to
                        recite there -- expected to score badly on exact-
                        match metrics, which is itself the honest point: hard
                        playback only really works for atomic, structured
                        facts, exactly INLAY's own limitation restated here.
  contextual_generation: the REASON path. Evidence formatted as short bullet
                        facts, fed to the base model as context, generated
                        freely -- no forced token ids anywhere.
"""
import torch


def format_evidence(card):
    """brief section 5's exact evidence format:
        Updated evidence:
        - [subject] --[relation]--> [object]
        - Source/time: [...]
    Falls back to raw evidence text when no clean subject/relation/object
    triple is available (unstructured mode)."""
    lines = ["Updated evidence:"]
    if card.canonical_fact_text:
        lines.append(f"- {card.canonical_fact_text}")
    elif card.raw_evidence_text:
        lines.append(f"- {card.raw_evidence_text[:300]}")
    if card.validity_start:
        lines.append(f"- Source/time: valid from {card.validity_start}")
    return "\n".join(lines)


def _chat_generate(model, tok, user_content, device, max_new_tokens):
    """Uses the model's own chat template rather than raw string concatenation.
    Bug found during the answering pilot: for an Instruct-tuned model, bare
    tok(prompt) leaves the model confused about turn structure, and it was
    visibly hallucinating a fake system-prompt continuation ('You are an AI
    assistant. You will be given a task...') instead of answering -- a real
    quality bug, not a scoring artifact, caught by reading actual generations
    rather than trusting the accuracy number alone."""
    messages = [{"role": "user", "content": user_content}]
    # explicit return_dict=True: this transformers version returns a
    # BatchEncoding here, not a raw tensor, and passing that whole object as
    # generate()'s positional input_ids arg crashes deep inside generate()
    # with an opaque AttributeError (a real bug caught by reading the actual
    # traceback, not the kind of thing a shape mismatch would explain).
    enc = tok.apply_chat_template(messages, add_generation_prompt=True,
                                  return_tensors="pt", return_dict=True).to(device)
    out = model.generate(**enc, max_new_tokens=max_new_tokens, do_sample=False,
                         pad_token_id=tok.eos_token_id)
    return tok.decode(out[0, enc["input_ids"].shape[1]:], skip_special_tokens=True).strip()


@torch.no_grad()
def answer_no_context(model, tok, query, device, max_new_tokens=20):
    return _chat_generate(model, tok, query, device, max_new_tokens)


def answer_hard_playback(card, gold):
    """Structured mode: the literal target_new (legitimate -- that IS the
    install-time edit spec, not a leak). Unstructured/extracted: the FIRST
    SENTENCE of the raw evidence only, not the full paragraph -- dumping the
    whole paragraph verbatim trivially contains the gold answer as a
    substring almost every time (the evidence text exists specifically to
    describe the new fact), which inflated an earlier pilot run's hard_playback
    score to 95% on unstructured mode through a scoring artifact, not genuine
    recitation accuracy. First-sentence-only is a fairer, still-honest
    operationalization of 'play back what was stored, no reasoning applied.'"""
    if card.input_mode == "structured" and gold and gold.target_new:
        return str(gold.target_new)
    text = card.raw_evidence_text or ""
    first_sentence = text.split(". ")[0]
    return first_sentence[:200]


@torch.no_grad()
def answer_contextual(model, tok, query, card, device, max_new_tokens=20, demonstrations=None):
    """demonstrations: optional list[str], IKE-style worked examples showing
    the override pattern ('New fact: ... Given this new fact, answer using
    it, not what you previously believed'), prepended before the actual
    evidence+question. Folds IKE's demonstrated finding (90.48% vs plain
    RAG's 87.07% on CounterFact unstructured, akew_baseline_comparison_
    results.md) into INLAY's own REASON path, on top of the retrieval/
    verification/routing machinery plain IKE and RAG lack entirely. None
    (the default) reproduces the exact prior behavior for every existing
    caller -- this is additive, not a silent behavior change."""
    evidence = format_evidence(card)
    demo_block = ("\n\n".join(demonstrations) + "\n\n") if demonstrations else ""
    user_content = f"{demo_block}{evidence}\n\nQuestion: {query}\nAnswer based only on the evidence above, in a few words."
    return _chat_generate(model, tok, user_content, device, max_new_tokens)


def _fold(text):
    """Diacritic-insensitive, case-insensitive normalization. Plain .lower()
    silently fails on names like Turkish 'Ismail' vs 'İsmail': Python's
    .lower() on 'İ' produces 'i' followed by a combining dot-above (U+0307),
    not plain ASCII 'i', so a factually-perfect generated answer scores as a
    miss against the gold string purely from encoding, not content -- a real
    bug found by reading an actual WikiUpdate example where the model's
    answer exactly matched gold and was still scored false. NFKD-decompose
    then strip combining marks (category Mn) before casefolding, which
    normalizes accented/dotted variants across languages generally, not just
    this one Turkish case."""
    import unicodedata
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return stripped.casefold()


def is_hit(generated_text, gold):
    """AKEW-style accuracy: does the generated text contain the gold answer
    or one of its aliases (diacritic- and case-insensitive substring)."""
    gl = _fold(generated_text)
    candidates = [str(gold.target_new or "")] + [str(a) for a in (gold.aliases_new or [])]
    for c in candidates:
        c = _fold(c.strip())
        if c and len(c) >= 2 and c in gl:
            return True
    return False
